# [Name] Design System

Design tokens and component patterns for the [Name] software resurrection landing page.

## Overview

Full landing page with cinematic hero (full-bleed video, glassmorphism) and dark scroll sections below. Sticky navigation with scroll-aware styling.

**Product context:** [Name] archives dormant software and brings it back as interactive prototypes — rebuilding dead repos in isolated sandboxes so anyone can experience the software again, not just screenshots and 404s.

## Page structure

| Section | ID | Purpose |
|---------|-----|---------|
| Hero | — | Video background, headline, email CTA, glass stats + testimonial cards |
| Problem | `#how-it-works` | Archive vs experience gap, key stats |
| Comparison | — | Before/after: 404 archive vs live sandbox |
| Pipeline | `#pipeline` | 4-step rebuild flow (Ingest → Repair → Isolate → Share) |
| Stats bar | — | Credibility metrics (Silkscreen numbers) |
| Use cases | `#use-cases` | Historians, M&A, OSS maintainers |
| CTA | `#early-access` | Email capture, request access |
| Footer | — | Links, legal |

## Typography

| Role | Font | Weight | Notes |
|------|------|--------|-------|
| Body / UI | Geist | 300–700 | Global default |
| Stats numbers | Silkscreen | 400 | `name-stat-number` class, `tracking-tight` |
| Section labels | Geist Mono | 500–600 | Uppercase, `tracking-[0.1em]` |

## Color System

### Core tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--name-black` | `#010101` | Hero text on mobile |
| `--name-bg` | `#0a0a0a` | Below-fold sections |
| `--name-bg-deep` | `#050505` | Footer |
| `--name-cta-top` | `#2B2B2B` | CTA gradient start |
| `--name-cta-bottom` | `#101010` | CTA gradient end |

### Hero responsive flip (`lg+`)

Near-black on small screens → white on `lg+` for headline, stats, testimonial (see hero section in code).

### Below-fold

White text on `#0a0a0a`. Muted copy at `white/50`–`white/60`. Borders at `white/10`.

## Glass & Blur

| Surface | Background | Blur |
|---------|------------|------|
| Nav pill | `bg-white/10` | `backdrop-blur-lg` |
| Hero cards | `bg-white/10` | `backdrop-blur-lg` |
| Sticky nav (scrolled) | `bg-black/70` | `backdrop-blur-xl` |
| Mobile overlay | `bg-black/80` | `backdrop-blur-md` |
| Mobile drawer | `bg-black/90` | `backdrop-blur-xl` |

## Navigation

- Fixed top, `z-50`
- Transparent on hero at top; `bg-black/70 backdrop-blur-xl border-white/10` when scrolled
- Anchor links: `#how-it-works`, `#use-cases`, `#pipeline`, `#early-access`
- Mobile drawer with staggered link animation (60ms steps)

## Components

| File | Component |
|------|-----------|
| `src/components/Logo.tsx` | Four-quadrant SVG mark |
| `src/components/Navigation.tsx` | Sticky nav + mobile menu |
| `src/components/GetStartedButton.tsx` | Dark gradient CTA pill |
| `src/components/SectionLabel.tsx` | Mono uppercase eyebrow |
| `src/sections/HeroSection.tsx` | Full-viewport video hero |
| `src/sections/ProblemSection.tsx` | Gap + stats |
| `src/sections/ComparisonSection.tsx` | Archive vs prototype |
| `src/sections/PipelineSection.tsx` | 4-step grid |
| `src/sections/UseCasesSection.tsx` | 3-column cards |
| `src/sections/StatsBarSection.tsx` | Metrics row |
| `src/sections/CtaSection.tsx` | Early access form |
| `src/sections/Footer.tsx` | Site footer |

## Hard bans

- No purple gradients
- No routing (single page)
- Silkscreen only on stat numbers

## File map

| File | Purpose |
|------|---------|
| `src/design-tokens.css` | CSS custom properties + utility classes |
| `src/index.css` | Tailwind import + theme font vars |
| `src/App.tsx` | Page composition |
| `DESIGN.md` | This document |
